# 80 — Concurrency domains and structured tasks

> **Status: proposed direction for discussion, 2026-09-16.** The user agreed
> with the general direction and requested this design document followed by
> further exploration. The user subsequently favored automatic timeslicing,
> subject to preserving the project's vision and invariants and producing an
> idiomatic, enjoyable concurrency API. Detailed scheduling, lifecycle, and
> cross-domain semantics remain open. Waiting rules must follow the principle
> of least astonishment: the model must make sense first. The subsequent
> discussion favors completion after cleanup, automatic scope joining, explicit
> outcomes, and debugger inspection before terminal failure. The user requested
> four adversarial reviews of this revision. This records a target model, not
> delivered capability or implementation authorization. Prepared against
> `03312562`; review findings are separate from accepted design decisions.

## 1. Direction

Use independently owned, mutable Runtimes for parallel execution and lightweight
structured tasks for concurrency within each Runtime. Communication between
Runtimes is explicit and asynchronous. Independent Runtimes can execute Birnam
code simultaneously; there is no global execution lock.

Call an independently owned Runtime a **domain**. Each domain contains an
ordinary live object environment, with its own heap, Store, dispatch state,
Machines, and code-generation ownership. Its mutable state has one execution
owner. Several tasks can share objects within that domain.

The long-term target is thread-hosted domains as the ordinary backend, with
process-hosted domains available for stronger fault containment and native
libraries that cannot safely coexist. Start with the existing process substrate;
thread hosting requires substantial ownership work and measured justification.

Keep the language-facing model independent of OS placement where its semantics
really are equivalent. Expose meaningful differences, especially native-crash
containment, termination, and resource cost.

### Design priorities

Preserving Birnam's vision and invariants is the governing constraint. Within
that constraint, prefer an idiomatic, understandable API with useful automatic
scheduling. Similarity to goroutines is a useful intuition, not a requirement to
copy Go's sharing model, primitives, or syntax. Implementation convenience must
not silently reduce malleability or force routine callers to manage scheduler
internals.

Waiting and lifecycle rules must follow the principle of least astonishment.
Give each operation a small, stable meaning that survives changes of scheduler
or hosting backend. Make exceptions visible at the relevant API boundary rather
than relying on users to understand runtime implementation details.

## 2. Relationship to existing designs

- [48](48-concurrency-reactors-and-isolates.md) supplies the retained blocking
  process-isolate contract and earlier reactor exploration. Its pre-stackless
  implementation constraints are historical. This proposal does not revive the
  withdrawn worker-replacement or rollout policy.
- [60A](60a-stackless-execution-semantics.md) and
  [60D](60d-stackless-concurrency-fit.md) supply owner-affine Machines, rooted
  resumable Frames, native barriers, and candidate scheduling boundaries.
- [74](74-malleable-multicore-execution-and-optimization.md) compares parallel
  owners, shared mutable execution, and transactional sessions. This document
  develops the parallel-owner candidate; it does not change optimization rules.
- [The isolate guide](../guide/06-isolates.md) remains the shipped public API.

Today, the Runtime drives a Machine to completion or explicit suspension rather
than enforcing a general scheduling budget. Isolate requests block through the
complete exchange while holding the worker registry mutex. The public IdApi and
several native modules retain process-wide Runtime state. None of these facts
is resolved merely by introducing the terminology below.

## 3. Vocabulary and ownership

| Term | Proposed meaning |
| --- | --- |
| Domain | One independently owned live Runtime and its mutable environment. |
| Task | A schedulable logical computation within a domain, using existing Machine/Frame machinery. |
| Scope | Owns child task lifetimes, result collection, cancellation, and cleanup. |
| Endpoint | A capability for explicit asynchronous communication with another domain. It does not expose a foreign Oop. |
| Reactor | Readiness and timer machinery that makes waiting tasks runnable. |
| Scheduler | Selects runnable tasks and assigns execution budgets. |

A domain can contain many objects and tasks. Creating a task does not require
creating an isolated heap or OS process. A task is a lifecycle abstraction over
execution; its exact relationship to nested Machines needs specification.

Local message sends retain ordinary synchronous Birnam semantics. A task may
be suspended while a result is pending, but its caller resumes with the normal
result. Cross-domain requests are explicit operations; an ordinary object send
must not silently acquire remote failure and transport semantics.

Initially, a domain remains pinned to its owner thread. Balance independent jobs
between domains through messages. Migrating live Machines or stealing tasks
across heaps is outside the initial design.

## 4. Why this direction

Birnam permits effectful lookup, method replacement, reflection, mutable object
structure, and native participation. Putting parallel threads inside one mutable
Runtime would require a concurrent memory model for all of those operations,
plus collection, Store access, callback entry, and executable reclamation.

Domain ownership preserves the local object model while concentrating parallel
coordination at explicit communication boundaries. It also allows a small native
mechanism with substantial policy authored in Birnam.

The costs are explicit: copied messages, per-domain runtime memory, communication
latency, and coordination of edits. Programs requiring frequent shared mutation
across cores may fit this model poorly. This proposal makes no throughput or
memory-efficiency claim before representative measurement.

An independently mutable domain is not a transactional view of one shared image.
If a universally shared live object world is a requirement, reconsider this
choice before implementing its public surface.

## 5. Malleability and invariant obligations

The following are requirements for a later implementation:

1. **Preserve local sends.** Keep evaluation order, effectful lookup, DNU,
   inheritance, supported MOP changes, identity, shared Cells, and current
   mutation visibility. Scheduling must not justify stale dispatch or replaying
   an effectful lookup.
2. **Preserve active execution.** An active Frame retains its entered
   implementation. Later sends resolve current dispatch, including after a
   suspended task resumes. Do not pin an entire task to an obsolete dispatch
   world merely because it started there.
3. **Preserve roots and code lifetime.** Ready queues, waits, task results,
   cancellation, and cleanup must retain and release the necessary object roots
   and generation pins. A stale readiness event must not resume completed or
   cancelled execution. Suspended Frames remain tied to their owner.
4. **Preserve native boundaries.** Do not suspend through arbitrary synchronous
   native activations or migrate their callbacks to another owner. Arbitrary
   native Methods remain supported without compiler recovery metadata.
5. **Preserve the malleable execution protocol.** Machines and StepActions remain
   observable Birnam objects under their existing contracts. Fairness cannot
   silently require sealed canonical implementations.
6. **Keep persistence honest.** Tasks, continuations, endpoints, scheduler queues,
   OS resources, and pending operations remain process-local. Persist explicit
   descriptions of durable work and recover new execution from them.
7. **Keep the bootstrap and authority model.** Retain independent cold bootstrap,
   compiled-unit authority, and the Store's role as data and reflection mirror.
   Scheduler or transport caches must not become competing dispatch authorities.

Single-owner execution prevents simultaneous mutation of a domain's memory; it
does not imply deterministic results or atomicity across a sequence of sends.
New task interleavings need an explicit semantic contract. Existing serial
programs must retain their behavior when no concurrent work is introduced.

This proposal does not amend the public IdApi, Method ABI, canonical descriptors,
or image formats. Thread hosting must first determine which changes are possible
within existing contracts and separately justify any necessary revisions.

## 6. Scheduling and shared state within a domain

### Preferred default: automatic timeslicing

The user's preference is automatic timeslicing rather than relying exclusively
on explicit waits/yields. Its precise safe-point and atomicity contracts still
need design; the preference does not waive existing native or runtime barriers.

Give resumable execution a bounded scheduling budget. When the budget expires,
return to the scheduler at an eligible Machine boundary and let another runnable
task proceed. I/O and explicit waits suspend the task and release its execution
opportunity immediately.

This provides automatic timeslicing for ordinary resumable code without
interrupting arbitrary native instructions. Counting StepAction transitions is
a starting mechanism, not a wall-clock latency guarantee.

The analogy to goroutines is lightweight execution with runtime-managed
scheduling: programmers do not insert a yield into every CPU loop. Go multiplexes
goroutines across OS threads and supports asynchronous preemption; see the
[Go FAQ](https://go.dev/doc/faq#goroutines) and
[runtime preemption implementation](https://go.dev/src/runtime/preempt.go).
Birnam's proposed tasks instead interleave within their owning domain at eligible
Machine boundaries, while independent domains supply multicore parallelism.
This proposal does not adopt Go's shared-heap execution model or promise its
ability to move other runnable work away from a blocked OS thread.

An eligible boundary must have rooted state, valid code pins, and no native
barrier, live host borrow, or runtime critical operation that forbids suspension.
The driver regaining control is necessary but not sufficient. Resuming another
task must also establish its own execution scope rather than inheriting an
unrelated synchronous callback's scope.

Long synchronous native Methods, blocking FFI calls, and custom implementations
that do unbounded work can still monopolize a domain. Use nonblocking adapters,
bounded operations, or another domain. Fairness guarantees must name the
execution paths they cover and expose overruns; they cannot make arbitrary
foreign code interruptible.

### Atomicity is an open design decision

Automatic timeslicing introduces interleavings even without an explicit wait.
For example, two tasks can both read the same counter before either writes its
incremented value. A single OS thread does not prevent this lost update.

The recommended direction is automatic fairness plus an explicit way to protect
short multi-send invariants. The protection mechanism is not selected: candidates
include task-aware mutual exclusion, a restricted non-yielding region, and a
serialized state-owner protocol. They have different reentry, deadlock, and
fairness costs. A non-yielding region must define what happens if it waits,
re-enters user code, exceeds its budget, or raises an error.

Task switching only at explicit waits/yields remains a comparison point: it
provides simpler straight-line reasoning but cannot protect responsiveness from
an ordinary CPU-bound task that never yields. Automatic timeslicing is the
preferred direction; choosing how to protect multi-send invariants is the next
decision before exposing a general scheduler.

## 7. Structured task lifecycle

Every task has an identifiable lifecycle owner. A scope owns its child tasks and
does not report successful completion while those children remain unresolved.
Long-lived services need an explicit service owner or supervisor rather than
accidentally escaping a short-lived request scope.

### Results and completion

A task is complete when its body, owned children, and required cleanup have
settled. There is one published terminal outcome: success with a value, failure
with evidence, or cancellation with a reason. Terminal publication is one-shot;
repeated observation does not execute the task again. Retaining the same result
value does not freeze or copy a mutable object returned within a domain.

The proposed public surface is:

| Operation | Proposed meaning |
| --- | --- |
| `scope fork: block` | Create a child task owned by the scope. |
| `task await` | Wait for settlement, return a successful value, otherwise propagate task failure or cancellation. |
| `task outcome` | Wait for settlement and return an inspectable success, failure, or cancellation outcome. |
| `task cancel` | Request cancellation; do not claim settlement or rollback. |

Scopes join their children automatically. Initially omit a separate public
`join`: both waiting operations already wait for lifecycle completion. An
operation that emits values before it finishes should expose an explicit stream
or channel rather than report a premature terminal result.

Ordinary Birnam Error objects remain values. Returning an Error object is a
successful return of that object; declaring task failure requires an explicit
operation whose spelling remains open. `await` failure propagation is a new
task-control operation, not permission to reinterpret existing Error returns as
exceptions. Its unwind, native-barrier, and reentry behavior must be specified
before implementation. `outcome` supplies observation without that propagation.
Unrecoverable VM corruption is not made recoverable by wrapping it in an outcome.

### Scope failure policy

For an ordinary scope, a terminal child failure requests cancellation of the
remaining scope work, including the scope body. The scope reports failure after
owned work and required cleanup settle. Retain independent child failures and
cleanup failures; do not let induced sibling cancellations obscure their cause.
If cleanup fails during cancellation, retain both that failure and the original
cancellation context rather than reporting clean cancellation.

An explicitly supervised scope may allow children to fail independently. Design
the ordinary scope first. Expected failures can be handled inside a child before
it declares terminal failure, or under a supervised policy. Merely observing a
failed child through `outcome` does not erase the ordinary scope's failure or
reverse cancellation already requested. Observation, recovery, and ownership
policy are distinct operations.

Open details include the aggregate outcome representation, treatment of explicitly
cancelled children on otherwise normal scope exit, and propagation when the scope
body itself fails or is cancelled. Define these through state-transition examples
before freezing selectors; do not infer a complete failure algebra from this
direction.

### Cancellation and deadlines

Cancellation is an idempotent request propagated through owned work. It takes
effect at eligible execution boundaries and uses the reviewed unwind/cleanup
path rather than discarding Frames or roots. Once delivered, it remains pending
through ordinary execution; cleanup may need narrowly scoped protection so
repeated cancellation does not prevent resource release. The mechanism and its
interaction with malleable control remain open.

Completion and cancellation race. A published success is not rewritten by a late
cancellation request. The exact delivery-versus-settlement linearization point
still needs specification. Requesting cancellation never proves that external
effects were undone, and a blocked native call can delay settlement indefinitely.

A wait timeout bounds observation, leaving ownership intact. A scope deadline
requests cancellation of the scope's work and then accounts for cleanup; it does
not promise cleanup finishes at the deadline. Domain termination has backend-
specific consequences and cannot be implemented as arbitrary thread unwinding.

A transport failure can leave remote execution uncertain. A local request handle
may settle with failure describing that uncertainty; it must not claim the remote
task or its cleanup completed. Ownership of outstanding remote activity and
reconciliation after disconnect still need an explicit protocol.

### Waiting rules: least astonishment

The following are proposed API requirements, prompted by the user's explicit
priority that the model make sense first:

- **An ordinary task wait suspends the caller.** Other runnable tasks in its
  domain remain eligible to execute. Foreign blocking operations that cannot
  provide this behavior need an explicit adapter or a documented blocking
  boundary; they must not masquerade as ordinary task waits.
- **Waiting does not grant exclusive access.** Other tasks may change shared
  state while the caller is suspended. With automatic timeslicing, absence of
  an explicit wait does not itself grant exclusive access either.
- **Waiting does not silently release synchronization.** If locks are offered,
  an ordinary wait must not implicitly unlock them. A specialized operation
  that releases and reacquires a lock must state that behavior. Lock-across-wait
  restrictions and deadlock handling still need specification.
- **Acceptance is not completion.** Submission success is not execution success.
  A task's terminal result is published only after its owned work and required
  cleanup settle. Intermediate outputs use a distinct stream/channel contract.
  Local request settlement after transport failure does not assert remote
  completion.
- **A wait timeout does not prove cancellation.** State whether a deadline
  merely ends waiting or also requests cancellation. Cancellation request,
  acknowledgement, and completed cleanup are distinct. None implies rollback
  of effects that already occurred.
- **Scope exit accounts for children.** Deadline expiry must not silently
  detach remaining work. If cleanup cannot settle within a requested bound,
  expose that unresolved state and its continuing owner. Do not promise both
  guaranteed bounded return and completed cleanup for arbitrary native calls.
- **Failure remains inspectable.** Preserve the distinction between an
  application result, runtime failure, remote failure, and an unknown outcome.
  Waiting must not trigger an implicit retry that can duplicate effects.

These requirements guide naming and examples. The proposed `await` and `outcome`
selectors remain reviewable and do not make waits safe in every synchronous
native calling context.

### Live debugging before terminal failure

The model should preserve Self-like inspectable execution inside a domain.
Self documents automatically scheduled processes with suspension, stepping,
stack inspection, and continuation through its
[process API](https://handbook.selflanguage.org/2024.1/processes.html) and
[debugger](https://handbook.selflanguage.org/2024.1/textdebug.html). Parallel
domains and structured scope lifetimes are additions proposed here, not claims
about Self's documented concurrency model.

An explicit debugger policy may intercept a recoverable failure before terminal
publication and irreversible unwinding. The task enters a visible debugger-
suspended state with its inspectable execution retained. It is unfinished; its
scope stays open, and waiters must be able to distinguish debugger suspension
from an opaque hang. The debugger can inspect, step, perform supported live edits,
and request supported continuation/recovery or terminal failure.

This is not automatic recovery from every error, arbitrary native activation, or
partially performed effect. Recovery capabilities depend on the actual stopped
state and existing control/native barriers. Active Frames retain their entered
implementation even if later sends observe a live edit. Do not silently replay
effectful operations or promise an already-unwound task can resume.

The ordinary scope's fail-fast rule starts when failure becomes terminal. While
the debugger retains the task, specify separately whether peers run or are paused;
do not freeze the whole domain implicitly. A paused task may hold locks, roots,
and code pins. The policy for peer dependencies, pending cancellation, scope
deadlines, debugger disconnect, and eventual release is still open and is a
required design question. Production scopes must not silently enter an indefinite
interactive debugging wait because the editor happened to be attached.

## 8. Messages and backpressure

Start with the existing admitted copied-value set and wire validation. Arbitrary
objects, Blocks, shared Cells, continuations, Aliens, and native pointers do not
cross the boundary. Domain identity can cross as an explicit value key; copied
objects do not retain cross-domain pointer identity.

Requests can be submitted independently of waiting for their results. Queues
must have bounded admission, with an explicit wait or rejection result when
full. Capacity must account for message bytes as well as item count.

The protocol must distinguish acceptance, delivery, completion, cancellation,
and an uncertain outcome. Do not promise exactly-once effects or automatically
retry requests whose external effects are unknown. Ordering scope and the
linearization point for completion-versus-cancellation remain to be specified.

Shared immutable buffers, ownership transfer, and remote references are possible
extensions. Each needs its own identity, lifetime, and failure rules. Persistent
collections alone do not prove that their reachable object graph can be shared
safely across domains.

## 9. Live editing across domains

Recommend local live mutation with explicit coordination across domains:

- Inspect and edit each live domain without requiring restart as the normal
  editing mechanism.
- Publish a compatible change at a valid local publication boundary. A generic
  scheduler timeslice is not automatically a safe code-publication boundary.
- Existing Frames continue in their retained implementation; later sends see
  the current local dispatch environment.
- A development tool can address a group of domains and report which domains
  accepted, rejected, or have not yet applied the change.

Independent activation means mixed generations can exist. Cross-domain protocols
need an explicit compatibility policy for messages already queued or in flight.
The presence of a version field alone does not solve that policy.

An instantaneous atomic edit across all domains is not a default guarantee. A
coordinated activation operation would require its own preparation, admission
fencing, publication, and partial-failure contract. It must not imply rollback
of external effects or automatically revive the withdrawn rollout design.

## 10. Implementation direction

Three bounded increments can establish the model:

1. **Usable parallel process workers.** Separate submission from waiting, remove
   the registry-lock-across-I/O bottleneck, and provide bounded outstanding work
   and explicit results. Preserve the shipped blocking API's failure contract.
2. **Structured tasks within a Runtime.** Add readiness integration, task
   ownership, fair driving, cancellation, and cleanup over existing Machines.
   Choose the interleaving/atomicity contract first. This work can begin alongside
   the transport increment; both must agree on waiting and completion semantics.
3. **Thread-hosted domains.** Replace process-global ownership assumptions with
   domain-qualified ownership. Audit IdApi routing, native module state, roots,
   callback entry, compiler/loader state, and shared executable lifetime. Initially
   retain owner-thread affinity and copied messages.

The process backend remains useful after thread hosting. A fatal native error
can take down every domain in one process; logical heap isolation is not process
fault isolation or a security sandbox. Current isolate timeouts can terminate a
worker process; that behavior cannot be silently reproduced by killing a thread.

Keep scheduling and lifecycle policy in Birnam where practical. Native mechanisms
enforce ownership, root/lifetime safety, readiness, and platform execution. The
exact primitive surface is a follow-up design, not a second scheduler hidden in
Rust. Existing method and lookup customization remains part of that boundary.

## 11. Evidence needed to choose and refine the design

Use a small set of representative scenarios rather than a release-sized matrix:

- Submit independent CPU jobs to two domains before awaiting either. Observe
  real execution overlap and measure elapsed time against sequential execution.
- Keep a timer or interactive request responsive while another task runs a
  resumable CPU loop. Measure scheduler latency and single-task overhead.
- Cancel waiting and runnable tasks; verify cleanup, roots, and code pins settle
  once, including races with completion and domain failure.
- Edit a method while an older Frame is suspended. Verify the retained Frame
  resumes correctly and a subsequent send observes the new method.
- Saturate a message queue and show bounded memory/admission behavior; inject
  failure after delivery and report uncertainty without implicit replay.

A responsive I/O service with parallel CPU work is the first product exercise.
Thread hosting additionally needs native-module independence and comparative
startup, memory, transport, and throughput measurements. Early process-worker
success does not qualify threaded hosting or coordinated live editing.

## 12. Exploration order

1. **Interleaving and atomicity:** with automatic timeslicing preferred, define
   eligible boundaries and how mutable code protects a multi-send invariant.
2. **Live-world scope:** confirm independent live domains are sufficient, then
   define the editing experience and compatibility during mixed generations.
3. **Task outcomes:** joining, cancellation, ordinary Error values, cleanup, and
   service supervision under failure.
4. **Communication:** bounded admission, ordering, result ownership, transferable
   values, and uncertain effects.
5. **Hosting:** the minimum native mechanism and costs of removing process-wide
   state while retaining existing ABI and native participation where possible.

Domain, task, and scope are working names. Public selectors and syntax should
follow these decisions and a few small program examples rather than precede them.

### API exercises

[80A — Concurrency API sketches](80a-concurrency-api-sketches.md) works through
these exercises with tentative message-send APIs and an explicit timeout example.

Explore the surface through three small programs before choosing selectors:

1. Fetch two independent resources concurrently, combine their results, and
   ensure neither operation outlives the owning scope unintentionally.
2. Submit CPU work to another domain while the caller remains responsive;
   clearly show which input values cross the ownership boundary.
3. Update shared state from two local tasks while preserving a multi-send
   invariant; show the synchronization and cancellation behavior explicitly.

Prefer sequential-looking task bodies whose waits suspend only the task, clear
ownership of child work, and result/cancellation operations that compose through
ordinary Birnam protocols. A suspension-capable operation must still respect its
calling context and native barriers; sequential-looking syntax does not make
every native caller suspendable. Keep domain boundaries visible where they
change sharing or failure semantics. Evaluate the examples for live inspection,
method replacement, cleanup, and comprehensible failure behavior as well as
brevity. These are API goals, not an accepted syntax or a decision to introduce
an async function category.
